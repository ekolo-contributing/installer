<?php
    return [
        'DB_CONNECTION' => 'mysql',
        'DB_HOST' => 'localhost',
        'DB_PORT' => '3306',
        'DB_DATABASE' => 'ekolo_framework',
        'DB_USERNAME' => 'root',
        'DB_PASSWORD' => ''
    ];