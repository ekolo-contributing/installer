<?php
	return [
		'middleware' => 'App\\Middleware',
		'controller' => 'App\\Controllers',
		'model' 	 => 'App\\Models',
	];