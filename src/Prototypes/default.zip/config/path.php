<?php

    return [
        'views' => 'views',
        'errors' => 'errors'
    ];