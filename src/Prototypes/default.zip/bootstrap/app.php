<?php
    require_once __DIR__.'/../vendor/autoload.php';

    use Ekolo\Framework\Bootstrap\Application;
    
    return new Application;