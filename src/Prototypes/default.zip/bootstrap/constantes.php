<?php
    /**
     * Ce fichier est reservé aux constantes à ajouter dans le projet
     */

    if (!defined('HELLO_WORLD')) {
        define('HELLO_WORLD', 'Hello world !');
    }