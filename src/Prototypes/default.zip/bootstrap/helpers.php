<?php
    /**
     * Ce fichier est reservé aux fonctions (méthodes) à ajouter dans le projet
     */

    if (!function_exists('hello_world')) {
        /**
         * Hello world
         * @return void
         */
        function hello_world() {
            echo "Hello world !";
        }
    }